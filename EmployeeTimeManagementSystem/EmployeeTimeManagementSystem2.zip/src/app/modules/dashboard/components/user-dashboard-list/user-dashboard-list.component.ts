import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-dashboard-list',
  templateUrl: './user-dashboard-list.component.html',
  styleUrls: ['./user-dashboard-list.component.css']
})
export class UserDashboardListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
