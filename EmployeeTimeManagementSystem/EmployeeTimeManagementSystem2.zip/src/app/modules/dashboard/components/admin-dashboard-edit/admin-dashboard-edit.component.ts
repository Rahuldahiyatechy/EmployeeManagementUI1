import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-dashboard-edit',
  templateUrl: './admin-dashboard-edit.component.html',
  styleUrls: ['./admin-dashboard-edit.component.css']
})
export class AdminDashboardEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
