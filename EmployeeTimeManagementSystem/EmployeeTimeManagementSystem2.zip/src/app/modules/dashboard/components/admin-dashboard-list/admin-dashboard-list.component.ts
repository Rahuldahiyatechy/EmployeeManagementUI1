import { Component, OnInit } from '@angular/core';
import { FormsModule} from '@angular/forms';

@Component({
  selector: 'app-admin-dashboard-list',
  templateUrl: './admin-dashboard-list.component.html',
  styleUrls: ['./admin-dashboard-list.component.css']
})
export class AdminDashboardListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  navigateToCreateNew()
  {
    console.log("hi");
  }

}
