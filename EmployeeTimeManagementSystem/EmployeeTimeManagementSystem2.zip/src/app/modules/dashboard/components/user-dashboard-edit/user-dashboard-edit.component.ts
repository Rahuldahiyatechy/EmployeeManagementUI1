import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-dashboard-edit',
  templateUrl: './user-dashboard-edit.component.html',
  styleUrls: ['./user-dashboard-edit.component.css']
})
export class UserDashboardEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
