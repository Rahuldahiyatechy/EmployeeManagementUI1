import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-attandance',
  templateUrl: './attandance.component.html',
  styleUrls: ['./attandance.component.css']
})
export class AttandanceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
