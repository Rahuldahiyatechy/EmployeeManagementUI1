import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registration-edit',
  templateUrl: './registration-edit.component.html',
  styleUrls: ['./registration-edit.component.css']
})
export class RegistrationEditComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
